package com.cs.quzzie.model;

public class ManageClass {
    String id;

    public ManageClass() {
    }

    public ManageClass(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
